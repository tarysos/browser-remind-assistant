import type { Reminder } from '../../types/reminder.js';
/**
 * 執行完整的啟動重建流程：
 * 1. 載入所有 enabled reminders
 * 2. 重建 alarms
 * 3. 檢查 missed reminders
 * 回傳需補提醒的 reminder 清單
 */
export declare function performStartupRebuild(): Promise<Reminder[]>;
/**
 * 設定 extension install / update 監聽
 */
export declare function setupInstallListener(onInstall: () => void, onUpdate: (previousVersion: string) => void): void;
/**
 * 設定 startup 監聽（瀏覽器啟動）
 */
export declare function setupStartupListener(onStartup: () => void): void;
//# sourceMappingURL=index.d.ts.map