import type { Reminder } from '../../types/reminder.js';
import type { TriggerResult } from '../trigger-evaluator/index.js';
export declare function getNotificationId(reminderId: string): string;
/** 建立系統通知 */
export declare function showNotification(reminder: Reminder, result: TriggerResult): Promise<string>;
/** 清除通知 */
export declare function clearNotification(reminderId: string): Promise<void>;
/** 使用者互動動作 */
export type NotificationAction = 'complete' | 'snooze' | 'skip' | 'click';
/** 從 notification ID 解析 reminder ID */
export declare function parseNotificationId(notifId: string): string | null;
/**
 * 設定通知互動監聽器
 * @param onAction 當使用者互動時的回調
 */
export declare function setupNotificationListeners(onAction: (reminderId: string, action: NotificationAction) => void): void;
//# sourceMappingURL=index.d.ts.map