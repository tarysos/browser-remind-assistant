import type { Reminder, RecurringSchedule, OneTimeSchedule } from '../../types/reminder.js';
/** OpenClaw polling alarm 名稱 */
export declare const OPENCLAW_POLL_ALARM_NAME = "openclaw:poll";
/** 產生 alarm 名稱，格式: reminder:{id} */
export declare function getAlarmName(reminderId: string): string;
/** 產生 snooze alarm 名稱，格式: snooze:{id} */
export declare function getSnoozeAlarmName(reminderId: string): string;
/** Alarm 解析結果 */
export type ParsedAlarm = {
    type: 'reminder' | 'snooze';
    reminderId: string;
} | {
    type: 'openclaw_poll';
};
/** 從 alarm 名稱解析類型與 ID */
export declare function parseAlarmName(alarmName: string): ParsedAlarm | null;
/** 計算單次提醒的觸發時間 */
export declare function getNextFireTimeOneTime(schedule: OneTimeSchedule): number | null;
/** 計算週期提醒的下一次觸發時間 */
export declare function getNextFireTimeRecurring(schedule: RecurringSchedule): number | null;
/** 為某筆提醒建立 alarm */
export declare function createAlarmForReminder(reminder: Reminder): Promise<void>;
/** 清除某筆提醒的 alarm */
export declare function clearAlarmForReminder(reminderId: string): Promise<void>;
/** 建立 snooze alarm */
export declare function createSnoozeAlarm(reminderId: string, delayMinutes: number): Promise<void>;
/** 清除所有本擴充建立的 alarm */
export declare function clearAllAlarms(): Promise<void>;
/** 為所有啟用中的提醒重建 alarm */
export declare function rebuildAllAlarms(reminders: Reminder[]): Promise<void>;
//# sourceMappingURL=index.d.ts.map