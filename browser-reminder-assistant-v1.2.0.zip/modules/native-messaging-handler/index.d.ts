import { type NativeCommand, type CommandResult } from '../../types/native-messaging.js';
/**
 * 向 native host 發送 poll 請求，取得待處理命令並逐筆執行。
 * 若 native host 未安裝，靜默回傳空結果。
 */
export declare function pollNativeHost(): Promise<CommandResult[]>;
declare function dispatchCommand(cmd: NativeCommand): Promise<CommandResult>;
export { dispatchCommand as _dispatchCommand };
//# sourceMappingURL=index.d.ts.map