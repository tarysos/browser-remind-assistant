export {};
//# sourceMappingURL=native-messaging-handler.test.d.ts.map