import type { Reminder, ReminderType } from '../../types/reminder.js';
import type { HistoryEntry, HistoryEventType, TriggerSource } from '../../types/history.js';
import type { GlobalSettings } from '../../types/settings.js';
export declare function generateId(prefix?: string): string;
/** 取得所有提醒（以 Record<id, Reminder> 形式） */
export declare function getAllReminders(): Promise<Record<string, Reminder>>;
/** 取得所有提醒（陣列） */
export declare function getAllRemindersArray(): Promise<Reminder[]>;
/** 依 ID 取得單筆提醒 */
export declare function getReminderById(id: string): Promise<Reminder | null>;
/** 新增提醒 */
export declare function createReminder(reminder: Reminder): Promise<Reminder>;
/** 更新提醒（整筆覆蓋） */
export declare function updateReminder(reminder: Reminder): Promise<Reminder>;
/** 刪除提醒 */
export declare function deleteReminder(id: string): Promise<void>;
/** 啟用 / 停用提醒 */
export declare function toggleReminder(id: string, enabled: boolean): Promise<Reminder>;
/** 依類型篩選 */
export declare function getRemindersByType(type: ReminderType): Promise<Reminder[]>;
/** 取得所有啟用中的提醒 */
export declare function getEnabledReminders(): Promise<Reminder[]>;
/** 取得所有歷史紀錄 */
export declare function getHistory(): Promise<HistoryEntry[]>;
/** 寫入一筆歷史紀錄 */
export declare function addHistoryEntry(reminderId: string, eventType: HistoryEventType, periodKey: string, source: TriggerSource): Promise<HistoryEntry>;
/** 取得特定提醒的歷史紀錄 */
export declare function getHistoryByReminderId(reminderId: string): Promise<HistoryEntry[]>;
/** 取得全域設定 */
export declare function getSettings(): Promise<GlobalSettings>;
/** 更新全域設定（部分更新） */
export declare function updateSettings(partial: Partial<GlobalSettings>): Promise<GlobalSettings>;
//# sourceMappingURL=index.d.ts.map