/**
 * 根據設定計算並更新 badge
 */
export declare function updateBadge(): Promise<void>;
/**
 * 清除 badge
 */
export declare function clearBadge(): Promise<void>;
//# sourceMappingURL=index.d.ts.map