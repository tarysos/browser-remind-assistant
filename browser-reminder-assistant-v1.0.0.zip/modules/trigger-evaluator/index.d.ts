import type { Reminder, PeriodKey } from '../../types/reminder.js';
import type { TriggerSource } from '../../types/history.js';
export interface TriggerResult {
    shouldTrigger: boolean;
    reason?: 'time_match' | 'first_open' | 'missed_catchup' | 'site_match';
    source: TriggerSource;
}
/** 取得今日的 daily period key: YYYY-MM-DD */
export declare function getDailyPeriodKey(date?: Date): PeriodKey;
/** 取得本週的 weekly period key: YYYY-Www */
export declare function getWeeklyPeriodKey(date?: Date): PeriodKey;
/** 依頻率取得對應的 period key */
export declare function getPeriodKey(frequency: 'daily' | 'weekly', date?: Date): PeriodKey;
/** 判斷目前時間是否在指定時段內 */
export declare function isWithinTimeWindow(startTime: string, endTime: string, now?: Date): boolean;
/**
 * 將 glob URL pattern 轉為 RegExp
 * 支援格式例如: "*://mail.google.com/*", "*://*.notion.so/*"
 */
export declare function urlPatternToRegExp(pattern: string): RegExp;
/** 檢查 URL 是否匹配任一 pattern */
export declare function matchesUrlPatterns(url: string, patterns: string[]): boolean;
/**
 * 評估一筆提醒是否應被觸發
 * @param reminder 待評估的提醒
 * @param source 觸發來源
 * @param currentUrl 目前分頁的 URL（僅 site_trigger 需要）
 */
export declare function evaluate(reminder: Reminder, source: TriggerSource, currentUrl?: string): TriggerResult;
/**
 * 批次評估所有提醒，回傳需觸發的清單
 */
export declare function evaluateAll(reminders: Reminder[], source: TriggerSource, currentUrl?: string): Array<{
    reminder: Reminder;
    result: TriggerResult;
}>;
/**
 * 檢查是否有過期但未處理的提醒（補提醒用）
 */
export declare function findMissedReminders(reminders: Reminder[]): Reminder[];
//# sourceMappingURL=index.d.ts.map